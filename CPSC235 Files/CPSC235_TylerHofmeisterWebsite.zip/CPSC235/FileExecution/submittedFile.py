import sys
submitted_expense_report = sys.argv[1]
budget_allocated_for_expenses = int(sys.argv[2])

def BudgetLeft():
    try:
        try:
            try:
                totalBudget = int(budget_allocated_for_expenses)
                expense_report = open(submitted_expense_report, "r")
                for line in expense_report:
                    expense = int(line)
                    totalBudget -= expense
                if totalBudget <= 0:
                    print "This expense report goes over budget!"
                else:
                    print totalBudget
            except ValueError:
                    print "You need to enter a valid amount for the budget!"
        except IOError:
            print "IOError, file not found"
    except:
        print "Unknown Error"
    finally:
        try:
            expense_report.close()
        except:
            pass
            
BudgetLeft()
