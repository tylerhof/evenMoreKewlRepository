package questions;

public class SimpleQuestion extends Question{
	public String correctAnswer;
	
	public SimpleQuestion(String Answer) {
		correctAnswer = Answer;
	}

	public boolean isCorrect(String submittedAnswer) {
		if (submittedAnswer.equals(correctAnswer)) {
			return true;
		} else {
			return false;
		}
	}

}

