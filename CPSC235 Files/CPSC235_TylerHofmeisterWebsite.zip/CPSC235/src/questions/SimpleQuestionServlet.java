package questions;

import java.io.IOException;

import userPackage.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import directory.ParentServlet;

/**
 * Servlet implementation class SimpleQuestionServlet
 */
@WebServlet("/SimpleQuestionServlet")
public class SimpleQuestionServlet extends ParentServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public SimpleQuestionServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		User User1 = (User) session.getAttribute("User");
		if (User1.isAnswered(request.getParameter("questionType"),
				request.getParameter("questionNumber"))) {
			forward("/Error.jsp", request, response);
		} else {
			User1.setAnswered(request.getParameter("questionType"),
					request.getParameter("questionNumber"));
			User1.overwriteUserData();
			String Answer = request.getParameter("submittedAnswer");
			SimpleQuestion Question = new SimpleQuestion(
					request.getParameter("correctAnswer"));
			if (Question.isCorrect(Answer)) {
				User1.setCorrect(request.getParameter("questionType"),
						request.getParameter("questionNumber"));
				User1.overwriteUserData();
				session.setAttribute("User", User1);
				forward(request.getParameter("nextPageIfCorrect"), request,
						response);
			} else {
				User1.overwriteUserData();
				session.setAttribute("User", User1);
				forward(request.getParameter("nextPageIfIncorrect"), request,
						response);
			}
		}
	}

	public void forward(String pageToGoTo, HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		ServletContext sc = getServletContext();
		RequestDispatcher rd = sc.getRequestDispatcher(pageToGoTo);
		rd.forward(request, response);
	}
}
