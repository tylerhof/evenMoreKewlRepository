package questions;

import java.io.IOException;


public abstract class Question {
	String correctAnswer;
	
	public abstract boolean isCorrect(String submittedAnswer) throws IOException;
	
	
	
}
