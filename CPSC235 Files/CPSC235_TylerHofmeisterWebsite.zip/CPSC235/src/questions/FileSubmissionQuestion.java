package questions;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;

public class FileSubmissionQuestion extends Question {

	public boolean checkForTry() throws IOException {
		BufferedReader reader = new BufferedReader(
				new FileReader(
						"/home/uga/tyler.hofmeister/testWorkspace/CPSC235/FileExecution/submittedFile.py"));
		String line = null;
		while ((line = reader.readLine()) != null) {
			if (!line.contains("try")) {
				reader.close();
				return true;
			}
		}
		reader.close();
		return false;
	}

	public void addNecessaryCode() throws IOException {
		BufferedReader reader = new BufferedReader(
				new FileReader(
						"/home/uga/tyler.hofmeister/testWorkspace/CPSC235/FileExecution/submittedFile.py"));
		File FileToTest = new File(
				"/home/uga/tyler.hofmeister/testWorkspace/CPSC235/FileExecution/FileToTest.py");
		if (!FileToTest.exists()) {
			FileToTest.createNewFile();
		}
		BufferedWriter writer = new BufferedWriter(
				new FileWriter(
						"/home/uga/tyler.hofmeister/testWorkspace/CPSC235/FileExecution/FileToTest.py"));
		writer.write("import sys" + "\n");
		writer.write("submitted_expense_report = sys.argv[1]" + "\n");
		writer.write("budget_allocated_for_expenses = int(sys.argv[2])" + "\n"
				+ "\n");

		String line = null;
		while ((line = reader.readLine()) != null) {
			if (!line.contains("sys")) {
				writer.write(line + "\n");
			}
		}
		writer.close();
		reader.close();
		File oldFile = new File(
				"/home/uga/tyler.hofmeister/testWorkspace/CPSC235/FileExecution/submittedFile.py");
		oldFile.delete();
		FileToTest.renameTo(oldFile);
	}

	public boolean runTest(String expectedOutput,
			String submitted_expense_report,
			String budget_allocated_for_expenses) throws IOException {
		File directoryToRun = new File(
				"/home/uga/tyler.hofmeister/testWorkspace/CPSC235/FileExecution/");
		ProcessBuilder CmdLineExecution = new ProcessBuilder("python",
				"submittedFile.py", submitted_expense_report,
				budget_allocated_for_expenses);
		CmdLineExecution.directory(directoryToRun);
		Process process = CmdLineExecution.start();
		BufferedReader in = new BufferedReader(new InputStreamReader(
				process.getInputStream()));
		long expiryTime = (System.currentTimeMillis() + 30000);
		boolean readyToRun = false;
		while (System.currentTimeMillis() < expiryTime) {
			if (in.ready()) {
				readyToRun = true;
				break;
			}
		}
		
		if (readyToRun) {
			String line = in.readLine();
			if (line != null && line.equals(expectedOutput)) {
				return true;
			}
		}
		
		return false;
	}

	public boolean isCorrect(String submittedAnswer) throws IOException {
		if (this.checkForTry()) {
			if (this.runTest("Unknown Error", "Test1.txt", "100")) {
				this.addNecessaryCode();
				if ((this.runTest(
						"You need to enter a valid amount for the budget!",
						"Test1.txt", "100")
						&& (this.runTest("IOError, file not found", "", "100"))
						&& (this.runTest("14", "Test2.txt", "100")) && (this
							.runTest("This expense report goes over budget!",
									"Test3.txt", "100")))) {
					return true;

				}
			}
		}
		return false;
	}

}


