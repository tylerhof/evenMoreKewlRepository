package questions;

import java.io.*;
import java.util.*;

import userPackage.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import directory.ParentServlet;

/**
 * Servlet implementation class SimpleQuestionServlet
 */
@WebServlet("/FileSubmissionQuestionServlet")
public class FileSubmissionQuestionServlet extends ParentServlet {
	private static final long serialVersionUID = 1L;
	private final static String UPLOAD_DIRECTORY = "/home/uga/tyler.hofmeister/testWorkspace/CPSC235/FileExecution";

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public FileSubmissionQuestionServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		User User1 = (User) session.getAttribute("User");
		if (ServletFileUpload.isMultipartContent(request)) {
			try {
				List<FileItem> items = new ServletFileUpload(
						new DiskFileItemFactory()).parseRequest(request);
				for (FileItem item : items) {
					if (!item.isFormField()) {
						String name = "submittedFile.py";
						item.write(new File(UPLOAD_DIRECTORY + File.separator
								+ name));
					}
				}
				if (User1.isFileSubmissionAnswered()) {
					forward("/Error.jsp", request, response);

				} else {
					User1.setFileSubmissionAnswered(true);
					User1.overwriteUserData();
					FileSubmissionQuestion Question = new FileSubmissionQuestion();
					if (Question.isCorrect("")) {
						User1.setFileSubmissionCorrect(true);
						User1.overwriteUserData();
						forward("/File Submission Question Correct.jsp",
								request, response);
					} else {
						User1.overwriteUserData();
						forward("/File Submission Question Incorrect.jsp",
								request, response);
					}
				}
			} catch (Exception ex) {
				forward("/Error.jsp", request, response);
			}
		} else {
			forward("/Error.jsp", request, response);
		}
	}

	public void forward(String pageToGoTo, HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		ServletContext sc = getServletContext();
		RequestDispatcher rd = sc.getRequestDispatcher(pageToGoTo);
		rd.forward(request, response);
	}

}
