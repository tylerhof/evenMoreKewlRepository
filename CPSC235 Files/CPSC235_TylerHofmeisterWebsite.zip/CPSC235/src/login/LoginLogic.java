package login;

import userPackage.*;

import java.io.*;

public class LoginLogic {
	private static final String USER_DATA_FILE_LOCATION = "/home/uga/tyler.hofmeister/testWorkspace/CPSC235/UserData.txt";

	public boolean isEmpty(String IDNumber, String Name) {
		if (IDNumber == null || Name == null || IDNumber.trim() == ""
				|| Name.trim() == "") {
			return true;
		} else {
			return false;
		}
	}

	public boolean doesExist(String IDNumber, String Name) {
		try {
			BufferedReader reader = new BufferedReader(new FileReader(
					USER_DATA_FILE_LOCATION));
			String line = null;
			while ((line = reader.readLine()) != null) {
				String[] result = line.split("/");
				if (IDNumber.equals(result[0])) {
					reader.close();
					return true;
				}
			}
			reader.close();
			return false;
		} catch (IOException ex) {
			return true;
		}
	}

	public boolean authenticate(String IDNumber, String Name) {
		try {
			BufferedReader reader = new BufferedReader(new FileReader(
					USER_DATA_FILE_LOCATION));
			String line = null;
			while ((line = reader.readLine()) != null) {
				String[] result = line.split("/");
				if (IDNumber.equals(result[0])) {
					if (Name.equals(result[1])) {
						reader.close();
						return true;
					}
				}
			}
			reader.close();
			return false;
		} catch (IOException ex) {
			System.err.println(ex.getMessage());
			return false;
		}
	}

	public User returnUser(String IDNumber, String Name) {
		try {
			BufferedReader reader = new BufferedReader(new FileReader(
					USER_DATA_FILE_LOCATION));
			String line = null;
			while ((line = reader.readLine()) != null) {
				String[] result = line.split("/");
				if (IDNumber.equals(result[0]) && Name.equals(result[1])) {
					User returnedUser = new User(result[0], result[1],
							result[2], this.returnBoolean(result[3]),
							this.returnBoolean(result[4]),
							this.returnBoolean(result[5]),
							this.returnBoolean(result[6]),
							this.returnBoolean(result[7]),
							this.returnBoolean(result[8]),
							this.returnBoolean(result[9]),
							this.returnBoolean(result[10]),
							this.returnBoolean(result[11]),
							this.returnBoolean(result[12]),
							this.returnBoolean(result[13]),
							this.returnBoolean(result[14]),
							this.returnBoolean(result[15]),
							this.returnBoolean(result[16]),
							this.returnBoolean(result[17]),
							this.returnBoolean(result[18]));
					reader.close();
					return returnedUser;
				}
			}
			reader.close();
			User nullUser = new User(null, null, null);
			return nullUser;
		} catch (IOException ex) {
			User nullUser = new User(null, null, null);
			return nullUser;
		}
	}

	public boolean returnBoolean(String booleanToCheck) {
		if (booleanToCheck.equals("true")) {
			return true;
		} else {
			return false;
		}
	}

	public boolean checkChars(String stringToCheck) {
		if (stringToCheck.equals("\\") || stringToCheck.equals("/")) {
			return true;
		}
		int numberOfCharsInCheckedString = stringToCheck.length();
		String[] charsToCheck = stringToCheck.split("");
		for (int i = 0; i < numberOfCharsInCheckedString; i++) {
			if (charsToCheck[i].equals("/") || charsToCheck[i].equals("\\")) {
				return true;
			}
		}
		return false;
	}


}