package login;

import java.io.IOException;

import userPackage.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import directory.ParentServlet;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends ParentServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public LoginServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String IDNumber = request.getParameter("IDNumber");
		String name = request.getParameter("Name");
		String reportCardRequested = request.getParameter("ReportCard");
		LoginLogic service = new LoginLogic();
		if (service.checkChars(name) || service.checkChars(IDNumber)) {
			forward("/ErrorSlash.jsp", request, response);
		} else {
			if (IDNumber.equals("000666") && name.equals("super")) {
				forward("/Admin.jsp", request, response);
			} else {
				boolean isEmpty = service.isEmpty(IDNumber, name);
				if (isEmpty) {
					forward("/ErrorBlank.jsp", request, response);
				} else {
					if (IDNumber.equals("000666")) {
						forward("/ErrorName.jsp", request, response);
					} else {
						boolean exists = service.doesExist(IDNumber, name);
						if (exists) {
							boolean nameCheck = service.authenticate(IDNumber,
									name);
							if (nameCheck) {
								User User1 = service.returnUser(IDNumber, name);
								boolean returnEmpty = service.isEmpty(
										User1.getIDNumber(), User1.getName());
								if (returnEmpty) {
									forward("/Error.jsp", request, response);
								} else {
									HttpSession session = request.getSession();
									session.setAttribute("User", User1);
									if (reportCardRequested != null && User1.isFileSubmissionAnswered()) {
										forward("/Report Card.jsp", request,
												response);
									} else {
										forward("/" + User1.getCurrentPage()
												+ ".jsp", request, response);
									}
								}
							} else {
								forward("/ErrorName.jsp", request, response);
							}
						} else {
							User User1 = new User(IDNumber, name,
									"What Is An Error");
							try {
								User1.writeUserData();
								HttpSession session = request.getSession();
								session.setAttribute("User", User1);
								forward("/What Is An Error.jsp", request,
										response);
							} catch (Exception e) {
								forward("/Error.jsp", request, response);
							}
						}
					}
				}
			}
		}
	}

	public void forward(String pageToGoTo, HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		ServletContext sc = getServletContext();
		RequestDispatcher rd = sc.getRequestDispatcher(pageToGoTo);
		rd.forward(request, response);
	}

}
