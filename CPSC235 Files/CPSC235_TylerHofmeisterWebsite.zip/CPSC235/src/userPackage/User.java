package userPackage;

import java.io.*;

public class User implements Serializable {
	private String IDNumber;
	private String Name;
	String currentPage;
	boolean textAnswered1;
	boolean textCorrect1;
	boolean textAnswered2;
	boolean textCorrect2;
	boolean textAnswered3;
	boolean textCorrect3;
	boolean multipleChoiceAnswered1;
	boolean multipleChoiceCorrect1;
	boolean multipleChoiceAnswered2;
	boolean multipleChoiceCorrect2;
	boolean multipleChoiceAnswered3;
	boolean multipleChoiceCorrect3;
	boolean multipleChoiceAnswered4;
	boolean multipleChoiceCorrect4;
	boolean fileSubmissionAnswered;
	boolean fileSubmissionCorrect;
	public static final String USER_DATA_FILE_LOCATION = "/home/uga/tyler.hofmeister/testWorkspace/CPSC235/UserData.txt";
	public static final String USER_DATA_TEMPORARY_FILE_LOCATION = "/home/uga/tyler.hofmeister/testWorkspace/CPSC235/TemporaryUserData.txt";

	public boolean isFileSubmissionAnswered() {
		return fileSubmissionAnswered;
	}

	public void setFileSubmissionAnswered(boolean fileSubmissionAnswered) {
		this.fileSubmissionAnswered = fileSubmissionAnswered;
	}

	public boolean isFileSubmissionCorrect() {
		return fileSubmissionCorrect;
	}

	public void setFileSubmissionCorrect(boolean fileSubmissionCorrect) {
		this.fileSubmissionCorrect = fileSubmissionCorrect;
	}

	private static final long serialVersionUID = 1L;

	public boolean isAnswered(String questionType, String questionNumber) {
		if (questionType.equals("multipleChoice")) {
			if (questionNumber.equals("1")) {
				return multipleChoiceAnswered1;
			}
			if (questionNumber.equals("2")) {
				return multipleChoiceAnswered2;
			}
			if (questionNumber.equals("3")) {
				return multipleChoiceAnswered3;
			}
			if (questionNumber.equals("4")) {
				return multipleChoiceAnswered4;
			}
		}
		if (questionType.equals("text")) {
			if (questionNumber.equals("1")) {
				return textAnswered1;
			}
			if (questionNumber.equals("2")) {
				return textAnswered2;
			}
			if (questionNumber.equals("3")) {
				return textAnswered3;
			}

		}
		return false;
	}

	public void setAnswered(String questionType, String questionNumber) {
		if (questionType.equals("multipleChoice")) {
			if (questionNumber.equals("1")) {
				this.multipleChoiceAnswered1 = true;
			}
			if (questionNumber.equals("2")) {
				this.multipleChoiceAnswered2 = true;
			}
			if (questionNumber.equals("3")) {
				this.multipleChoiceAnswered3 = true;
			}
			if (questionNumber.equals("4")) {
				this.multipleChoiceAnswered4 = true;
			}
		}
		if (questionType.equals("text")) {
			if (questionNumber.equals("1")) {
				this.textAnswered1 = true;
			}
			if (questionNumber.equals("2")) {
				this.textAnswered2 = true;
			}
			if (questionNumber.equals("3")) {
				this.textAnswered3 = true;
			}
		}
		if (questionType.equals("file") && (questionNumber.equals("1"))) {
			this.fileSubmissionAnswered = true;
		}
	}

	public void setCorrect(String questionType, String questionNumber) {
		if (questionType.equals("multipleChoice")) {
			if (questionNumber.equals("1")) {
				this.multipleChoiceCorrect1 = true;
			}
			if (questionNumber.equals("2")) {
				this.multipleChoiceCorrect2 = true;
			}
			if (questionNumber.equals("3")) {
				this.multipleChoiceCorrect3 = true;
			}
			if (questionNumber.equals("4")) {
				this.multipleChoiceCorrect4 = true;
			}
		}
		if (questionType.equals("text")) {
			if (questionNumber.equals("1")) {
				this.textCorrect1 = true;
			}
			if (questionNumber.equals("2")) {
				this.textCorrect2 = true;
			}
			if (questionNumber.equals("3")) {
				this.textCorrect3 = true;
			}

		}
		if (questionType.equals("file")) {
			this.fileSubmissionCorrect = true;
		}
	}

	public boolean isCorrect(String questionType, String questionNumber) {
		if (questionType.equals("multipleChoice")) {
			if (questionNumber.equals("1")) {
				return multipleChoiceCorrect1;
			}
			if (questionNumber.equals("2")) {
				return multipleChoiceCorrect2;
			}
			if (questionNumber.equals("3")) {
				return multipleChoiceCorrect3;
			}
			if (questionNumber.equals("4")) {
				return multipleChoiceCorrect4;
			}
		}
		if (questionType.equals("text")) {
			if (questionNumber.equals("1")) {
				return textCorrect1;
			}
			if (questionNumber.equals("2")) {
				return textCorrect2;
			}
			if (questionNumber.equals("3")) {
				return textCorrect3;
			}
			

		}
		if (questionType.equals("file")) {
			return fileSubmissionCorrect;
		}
		return false;
	}

	public String getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(String currentPage) {
		this.currentPage = currentPage;
	}

	public String getIDNumber() {
		return IDNumber;
	}

	public String getName() {
		return Name;
	}

	public User(String submittedIDNumber, String submittedName, String page) {
		IDNumber = submittedIDNumber;
		Name = submittedName;
		currentPage = page;
		textAnswered1 = false;
		textCorrect1 = false;
		textAnswered2 = false;
		textCorrect2 = false;
		textAnswered3 = false;
		textCorrect3 = false;
		multipleChoiceAnswered1 = false;
		multipleChoiceCorrect1 = false;
		multipleChoiceAnswered2 = false;
		multipleChoiceCorrect2 = false;
		multipleChoiceAnswered3 = false;
		multipleChoiceCorrect3 = false;
		multipleChoiceAnswered4 = false;
		multipleChoiceCorrect4 = false;		
		fileSubmissionAnswered = false;
		fileSubmissionCorrect = false;
	}

	public User(String submittedIDNumber, String submittedName, String page,
			boolean text1, boolean text1right, boolean text2,
			boolean text2right, boolean text3, boolean text3right, boolean mc1,
			boolean mc1right, boolean mc2, boolean mc2right, boolean mc3,
			boolean mc3right, boolean mc4,
			boolean mc4right, boolean file, boolean fileRight) {
		IDNumber = submittedIDNumber;
		Name = submittedName;
		currentPage = page;
		textAnswered1 = text1;
		textCorrect1 = text1right;
		textAnswered2 = text2;
		textCorrect2 = text2right;
		textAnswered3 = text3;
		textCorrect3 = text3right;
		multipleChoiceAnswered1 = mc1;
		multipleChoiceCorrect1 = mc1right;
		multipleChoiceAnswered2 = mc2;
		multipleChoiceCorrect2 = mc2right;
		multipleChoiceAnswered3 = mc3;
		multipleChoiceCorrect3 = mc3right;
		multipleChoiceAnswered4 = mc4;
		multipleChoiceCorrect4 = mc4right;
		fileSubmissionAnswered = file;
		fileSubmissionCorrect = fileRight;
	}


	public void writeUserData() throws IOException {
		BufferedWriter writer = new BufferedWriter(new FileWriter(
				USER_DATA_FILE_LOCATION, true));
		writer.write(this.getIDNumber() + "/");
		writer.write(this.getName() + "/");
		writer.write(this.getCurrentPage() + "/");
		writer.write(this.isAnswered("text", "1") + "/");
		writer.write(this.isCorrect("text", "1") + "/");
		writer.write(this.isAnswered("text", "2") + "/");
		writer.write(this.isCorrect("text", "2") + "/");
		writer.write(this.isAnswered("text", "3") + "/");
		writer.write(this.isCorrect("text", "3") + "/");
		writer.write(this.isAnswered("multipleChoice", "1") + "/");
		writer.write(this.isCorrect("multipleChoice", "1") + "/");
		writer.write(this.isAnswered("multipleChoice", "2") + "/");
		writer.write(this.isCorrect("multipleChoice", "2") + "/");
		writer.write(this.isAnswered("multipleChoice", "3") + "/");
		writer.write(this.isCorrect("multipleChoice", "3") + "/");
		writer.write(this.isAnswered("multipleChoice", "4") + "/");
		writer.write(this.isCorrect("multipleChoice", "4") + "/");
		writer.write(this.isFileSubmissionAnswered() + "/");
		writer.write(this.isFileSubmissionCorrect() + "\n");
		writer.close();
	}

	public void overwriteUserData() throws IOException {
		BufferedReader reader = new BufferedReader(new FileReader(
				USER_DATA_FILE_LOCATION));
		File tempFile = new File(USER_DATA_TEMPORARY_FILE_LOCATION);
		tempFile.createNewFile();
		BufferedWriter writer = new BufferedWriter(new FileWriter(
				USER_DATA_TEMPORARY_FILE_LOCATION));
		String line = null;
		while ((line = reader.readLine()) != null) {
			String[] result = line.split("/");
			if (this.getIDNumber().equals(result[0])
					&& this.getName().equals(result[1])) {
				writer.write(this.getIDNumber() + "/");
				writer.write(this.getName() + "/");
				writer.write(this.getCurrentPage() + "/");
				writer.write(this.isAnswered("text", "1") + "/");
				writer.write(this.isCorrect("text", "1") + "/");
				writer.write(this.isAnswered("text", "2") + "/");
				writer.write(this.isCorrect("text", "2") + "/");
				writer.write(this.isAnswered("text", "3") + "/");
				writer.write(this.isCorrect("text", "3") + "/");
				writer.write(this.isAnswered("multipleChoice", "1") + "/");
				writer.write(this.isCorrect("multipleChoice", "1") + "/");
				writer.write(this.isAnswered("multipleChoice", "2") + "/");
				writer.write(this.isCorrect("multipleChoice", "2") + "/");
				writer.write(this.isAnswered("multipleChoice", "3") + "/");
				writer.write(this.isCorrect("multipleChoice", "3") + "/");
				writer.write(this.isAnswered("multipleChoice", "4") + "/");
				writer.write(this.isCorrect("multipleChoice", "4") + "/");
				writer.write(this.isFileSubmissionAnswered() + "/");
				writer.write(this.isFileSubmissionCorrect() + "\n");
			} else {
				writer.write(line + "\n");
			}
		}
		File oldFile = new File(USER_DATA_FILE_LOCATION);
		oldFile.delete();
		tempFile.renameTo(oldFile);
		writer.close();
		reader.close();
	}

}
