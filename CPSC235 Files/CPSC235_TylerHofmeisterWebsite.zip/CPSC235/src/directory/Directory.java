package directory;
import userPackage.*;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Directory
 */
@WebServlet("/Directory")
public class Directory extends ParentServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Directory() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String requestedPage = request.getParameter("requestedPage");
		if (requestedPage.equals("LoginPage")) {
			forward(requestedPage, request, response);
		} else {
			HttpSession session = request.getSession();
			User User1 = (User) session.getAttribute("User");
			User1.setCurrentPage(requestedPage);
			try {
			User1.overwriteUserData();
			} catch (Exception e) {
				forward("/Error.jsp", request, response);
			}
			forward(requestedPage, request, response);
		}
	}
	
	public void forward(String pageToGoTo, HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ServletContext sc = getServletContext();
		RequestDispatcher rd = sc.getRequestDispatcher("/" + pageToGoTo
				+ ".jsp");
		rd.forward(request, response);	
	}

}
